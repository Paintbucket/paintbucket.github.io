--------------------------------------
Dr. Dobb's Singularity README
--------------------------------------

-----
What?
-----
Dr. Dobb's Singularity is a space-puzzle-adventure game in which the player takes control of the good doctor's space ship and needs to navigate through a number of levels with increasing difficulty. The game is a modification of Dr. Dobb's Challange, and also an entry in the competition with the same name.

----
How?
----
The game utilizes only a single button (SPACE) for the in game controls. The ship is automatically pulled downward and forward by the forces of space and the SPACE button thrusts the ship upward.

There are various "modifier tiles" in the levels which alters the ship's movement in different ways;

Switch direction (right) - Switches direction of the space ship so that it moves to the right.
Switch direction (left)  - Switches direction of the space ship so that it moves to the left.
Boost					 - Increases the velocity of the ship by a small amount.


Half of the game's levels are locked from the start but can be unlocked by earning medals. Medals are aquired when a level is completed in a good enough time, depending on the level. Bronze, Silver and Gold medals can be earned, with increasing demands on a fast time for each value. 

Many levels contain short cuts which can be traversed.. While these shortcuts routes are usually more difficult to pass than the normal route, they can significantly shorten the time needed to complete a level.

----
Why?
----
I have always liked the press-one-button-while-your-ship-flies-in-one-direction-and-needs-to-dodge-obstacles kind of games but they are often very much alike from one game to another. So, I thought that it would be a cool idea to spice things up a bit by creating a kind of puzzle game in the same atmosphere, while keeping the element of required dexterity.

----
Who?
----
Game Created by: Mattias Thell
Music by: Marcus Thell

----
P.S. 
----
Enjoy the programmer art :)